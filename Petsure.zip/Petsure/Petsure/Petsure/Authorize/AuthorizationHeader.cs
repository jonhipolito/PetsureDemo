﻿using Petsure.ExceptionLog;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace Petsure.Authorize
{
    public class AuthorizationHeader : DelegatingHandler
    {

        private ErrorLog oErrorLog = new ErrorLog();
        #region Send method.
        /// <summary>   
        /// Send method.   
        /// </summary>   
        /// <param name="request">Request parameter</param>   
        /// <param name="cancellationToken">Cancellation token parameter</param>   
        /// <returns>Return HTTP response.</returns>   
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            // Initialization.  
            try
            {
                AuthenticationHeaderValue authorization = request.Headers.Authorization;
                var headerValue = ConfigurationManager.AppSettings["HeaderValue"].ToString();

                if (headerValue.Equals(authorization.Scheme))
                {
                    // Setting   
                    var identity = new GenericIdentity(headerValue);
                    SetPrincipal(new GenericPrincipal(identity, null));
                }
            }
            catch (Exception ex)
            {

                oErrorLog.WriteErrorLog(ex.ToString());
            }

            return base.SendAsync(request, cancellationToken);
        }
        #  endregion
        #region Set principal method.  
        /// <summary>   
        /// Set principal method.   
        /// </summary>   
        /// <param name="principal">Principal parameter</param>   
        private static void SetPrincipal(IPrincipal principal)
        {
            // setting.   
            Thread.CurrentPrincipal = principal;
            // Verification.   
            if (HttpContext.Current != null)
            {
                // Setting.   
                HttpContext.Current.User = principal;
            }
        }
        #endregion
    }
}