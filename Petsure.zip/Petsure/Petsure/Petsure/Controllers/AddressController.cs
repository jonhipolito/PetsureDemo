﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Petsure.ExceptionLog;
using Petsure.Models;
using Petsure.Service;

namespace Petsure.Controllers
{
    public class AddressController : ApiController
    {
        private PetsureContext db = new PetsureContext();

        private ErrorLog oErrorLog = new ErrorLog();
        private IAddressService _addressService;


        public AddressController(IAddressService addressService)
        {
            try
            {
                this._addressService = addressService;
            }
            catch (Exception ex)
            {

                oErrorLog.WriteErrorLog(ex.ToString());
            }

        }

        // GET: api/Address
        [HttpGet]
        [Route("api/GetAddressList")]
        public IHttpActionResult GetAddresses()
        {
            var data = this._addressService.GetAddress();

            if (data != null)
            {
                return Ok(data);
            }
            return NotFound();
        }

        // GET: api/Address/5
        [HttpGet]
        [Route("api/GetAddressById/{Id}")]
        [ResponseType(typeof(Address))]
        public IHttpActionResult GetAddress(int id)
        {
            var data = this._addressService.GetAddressById(id);

            if (data == null)
            {
                return NotFound();
            }

            return Ok(data);
        }

        // PUT: api/Address/5
        [HttpPut]
        [Route("api/UpdateAddress/{Id}")]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutAddress(int id, Address address)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != address.Id)
            {
                return BadRequest();
            }

            var data = this._addressService.UpdateAddress(id, address);

            if (data != null)
            {
                return Ok(address);
            }
            else
            {
                return StatusCode(HttpStatusCode.NotModified);
            }
        }

        // POST: api/Address
        [HttpPost]
        [Route("api/CreateAddress")]
        [ResponseType(typeof(Address))]
        public IHttpActionResult PostAddress(Address address)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var data = this._addressService.CreateAddress(address);

            if (data != null)
            {
                return Ok(address);
            }
            else
            {
                return StatusCode(HttpStatusCode.NotImplemented);
            }
            
        }

        // DELETE: api/Address/5
        [ResponseType(typeof(Address))]
        public IHttpActionResult DeleteAddress(int id)
        {
            var data = this._addressService.DeleteAddress(id);

            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                return StatusCode(HttpStatusCode.NotFound);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool AddressExists(int id)
        {
            return db.Addresses.Count(e => e.Id == id) > 0;
        }
    }
}