﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Petsure.Models;
using Petsure.Service;
using Petsure.ExceptionLog;

namespace Petsure.Controllers
{
   [Authorize]
    public class CustomerController : ApiController
    {
        private ErrorLog oErrorLog = new ErrorLog();
        private ICustomerService _customerService;


        public CustomerController(ICustomerService customerService)
        {
            try
            {
                this._customerService = customerService;
            }
            catch (Exception ex)
            {

                oErrorLog.WriteErrorLog(ex.ToString());
            }
            
        }

        // GET: api/Customer
        [HttpGet]
        [Route("api/GetCustomerList")]
        public IHttpActionResult GetCustomers()
        {
                var data = this._customerService.GetCustomers();

                if (data != null)
                {
                    return Ok(data);
                }
            return NotFound();

        }

        // GET: api/Customer/5
        [HttpGet]
        [Route("api/GetCustomerById/{Id}")]
        [ResponseType(typeof(Customer))]
        public IHttpActionResult GetCustomerById(int id)
        {

            var data = this._customerService.GetCustomerById(id);

            if (data == null)
            {
                return NotFound();
            }

            return Ok(data);
        }

        // PUT: api/Customer/5
        [HttpPut]
        [Route("api/UpdateCustomer/{Id}")]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutCustomer(int id, Customer customer)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != customer.Id)
            {
                return BadRequest();
            }

            var data = this._customerService.UpdateCustomer(id, customer);

            if (data != null)
            {
                return Ok(customer);
            }
            else
            {
                return StatusCode(HttpStatusCode.NotModified);
            }

           
        }

        // POST: api/Customer
        [HttpPost]
        [Route("api/CreateCustomer")]
        [ResponseType(typeof(List<Customer>))]
        public IHttpActionResult PostCustomer(Customer customer)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var data = this._customerService.CreateCustomer(customer);

            if (data != null)
            {
                return Ok(customer);
            }
            else
            {
                return StatusCode(HttpStatusCode.NotImplemented);
            }
        }

        // DELETE: api/Customer/5
        [HttpDelete]
        [Route("api/DeleteCustomer")]
        [ResponseType(typeof(Customer))]
        public IHttpActionResult DeleteCustomer(int id)
        {
            var data = this._customerService.DeleteCustomer(id);

            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                return StatusCode(HttpStatusCode.NotFound);
            }
        }


    }
}