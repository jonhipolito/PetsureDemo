namespace Petsure.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using Petsure.Models;

    internal sealed class Configuration : DbMigrationsConfiguration<PetsureContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(Petsure.Models.PetsureContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            context.Customers.AddOrUpdate(x => x.Id,
                new Customer()
                {
                    Id = 1,
                    FullName = "John Wick",
                    DOB = "1987",
                    Age = 31,
                                //AddressId = 1,          
                 },
                new Customer()
                {
                    Id = 2,
                    FullName = "John Wayne",
                    DOB = "1937",
                    Age = 31,
                                //AddressId = 2,
                 }
            );


            context.Addresses.AddOrUpdate(x => x.Id,
                new Address() { Id = 1, Addressline_1 = "Wall Street", Addressline_2= "Broadway", City = "New York City", State = "New York", CustomerId = 1 },
                new Address() { Id = 2, Addressline_1 = "Rodeo Drive", Addressline_2 = "Sunset Blvd", City = "Los Angeles", State = "California" , CustomerId = 2}
                );


        }
    }
}
