﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Petsure.Models
{
    public class Address
    {
        public int Id { get; set; }
        [Required]
        public string Addressline_1 { get; set; }
        public string Addressline_2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public int CustomerId { get; set; }
    }
}