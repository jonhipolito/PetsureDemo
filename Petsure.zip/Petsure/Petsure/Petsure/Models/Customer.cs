﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Petsure.Models
{
    public class Customer
    {
        public int Id { get; set; }
        [Required]
        public string FullName { get; set; }
        public string DOB { get; set; }
        public int Age { get; set; }
        //FK
        //public int AddressId { get; set; }
        public List<Address> AddressList { get; set; }
    }
}