﻿using Petsure.ExceptionLog;
using Petsure.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Web;

namespace Petsure.Service
{
    public class AddressService : IAddressService
    {
        private ErrorLog oErrorLog = new ErrorLog();
        public List<Address> GetAddress()
        {

            using (var con = new PetsureContext())
            {
                try
                {
                    return con.Addresses.ToList();
                }
                catch (Exception ex)
                {
                    oErrorLog.WriteErrorLog(ex.ToString());
                    throw ex;
                }

            }

        }

        public List<Address> GetAddressById(int id)
        {
            using (var con = new PetsureContext())
            {
                try
                {
                    return con.Addresses.Where(x => x.Id == id).ToList();
                }
                catch (Exception ex)
                {
                    oErrorLog.WriteErrorLog(ex.ToString());
                    throw ex;
                }

            }

        }

        public Address UpdateAddress(int id, Address address)
        {

            using (var con = new PetsureContext())
            {
                try
                {
                    con.Entry(address).State = EntityState.Modified;
                    con.SaveChanges();
                    return address;
                }
                catch (DbUpdateConcurrencyException ex)
                {
                    oErrorLog.WriteErrorLog(ex.ToString());
                    throw ex;
                }

            }
        }

        public Address CreateAddress(Address address)
        {
            using (var con = new PetsureContext())
            {
                try
                {
                    con.Addresses.Add(address);
                    con.SaveChanges();
                    return address;
                }
                catch (DbUpdateConcurrencyException ex)
                {
                    oErrorLog.WriteErrorLog(ex.ToString());
                    throw ex;
                }

            }
        }

        public Address DeleteAddress(int id)
        {
            using (var con = new PetsureContext())
            {
                try
                {
                    Address address = con.Addresses.Find(id);
                    if (address == null)
                    {
                        return address;
                    }
                    con.Addresses.Remove(address);
                    con.SaveChanges();
                    return address;
                }
                catch (DbUpdateConcurrencyException ex)
                {
                    oErrorLog.WriteErrorLog(ex.ToString());
                    throw ex;
                }

            }
        }
    }
}