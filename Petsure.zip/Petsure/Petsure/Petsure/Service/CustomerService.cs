﻿using Petsure.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity.Infrastructure;
using System.Data.Entity;
using Petsure.ExceptionLog;

namespace Petsure.Service
{
    public class CustomerService : ICustomerService
    {
        private ErrorLog oErrorLog = new ErrorLog();
        public List<Customer> GetCustomers()
        {

            using (var con = new PetsureContext())
            {
                try
                {
                    return con.Customers.Include(c => c.AddressList).ToList();
                }
                catch (Exception ex)
                {
                    oErrorLog.WriteErrorLog(ex.ToString());
                    throw ex;
                }
                
            }
           
        }

        public List<Customer> GetCustomerById(int id)
        {
            using (var con = new PetsureContext())
            {
                try
                {
                    return con.Customers.Include(c => c.AddressList).Where(x => x.Id == id).ToList();
                }
                catch (Exception ex)
                {
                    oErrorLog.WriteErrorLog(ex.ToString());
                    throw ex;
                }
                
            }
        
        }

        public Customer UpdateCustomer(int id, Customer customer)
        {

            using (var con = new PetsureContext())
            {               
               try
                {
                    con.Entry(customer).State = EntityState.Modified;
                    if (customer.AddressList.Any())
                    {
                        customer.AddressList.ForEach(a => con.Entry(a).State = EntityState.Modified);
                    }
                    con.SaveChanges();
                    return customer;
                }
                catch (DbUpdateConcurrencyException ex)
                {
                    oErrorLog.WriteErrorLog(ex.ToString());
                    throw ex;
                }

            }
        }

        public Customer CreateCustomer(Customer customer)
        {
            using (var con = new PetsureContext())
            {
                try
                {
                    con.Customers.Add(customer);
                    var row = customer.AddressList;

                    if (row.Any())
                    {
                        con.Addresses.AddRange(row);
                    }
                    con.SaveChanges();
                    return customer;
                }
                catch (Exception ex)
                {
                    oErrorLog.WriteErrorLog(ex.ToString());
                    throw ex;
                }

            }
        }

        public Customer DeleteCustomer(int id)
        {
            using (var con = new PetsureContext())
            {
                try
                {
                    Customer customer = con.Customers.Find(id);
                    if (customer == null)
                    {
                        return null;
                    }
                    con.Customers.Remove(customer);
                    con.SaveChanges();
                    return customer;
                }
                catch (DbUpdateConcurrencyException ex)
                {
                    oErrorLog.WriteErrorLog(ex.ToString());
                    throw ex;
                }

            }
        }

    }
}