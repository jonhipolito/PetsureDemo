﻿using Petsure.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petsure.Service
{
    public interface IAddressService
    {
        List<Address> GetAddress();

        List<Address> GetAddressById(int id);

        Address UpdateAddress(int id, Address customer);

        Address CreateAddress(Address customer);

        Address DeleteAddress(int id);

    }
}
