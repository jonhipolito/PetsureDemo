﻿using Petsure.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petsure.Service
{
    public interface ICustomerService
    {
        List<Customer> GetCustomers();

        List<Customer> GetCustomerById(int id);

        Customer UpdateCustomer(int id, Customer customer);

        Customer CreateCustomer(Customer customer);

        Customer DeleteCustomer(int id);

    }
}
